package edu.depaul;

public interface OrderProcessor {
	
    void placeOrder(Order order);
}

