package edu.depaul;

public interface PaymentGateway {
    void processPayment(Order order);
}
