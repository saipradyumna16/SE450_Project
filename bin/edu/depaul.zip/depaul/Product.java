package edu.depaul;
public interface Product {

    String getName();
    public double getPrice();

    String toString(); 
 }