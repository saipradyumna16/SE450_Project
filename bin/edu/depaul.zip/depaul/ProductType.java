package edu.depaul;

public enum ProductType {
    CLOTHES, ELECTRONICS, BEAUTY, FURNITURE
}
